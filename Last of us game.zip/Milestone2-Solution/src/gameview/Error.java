package gameview;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Error extends JFrame implements KeyListener{
	
	public Error(String message) {
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
		setSize(400, 100);
		setResizable(false);
		setTitle("Error");
		addKeyListener(this);
		
		JLabel m = new JLabel();
		m.setText(message);
		m.setHorizontalTextPosition(JLabel.CENTER);
		m.setVerticalTextPosition(JLabel.CENTER);
		m.setBounds(0,0,200,100);
		
		JLabel enterKey = new JLabel();
		enterKey.setText("*Press Enter To Close This Window");
		enterKey.setHorizontalTextPosition(JLabel.CENTER);
		enterKey.setVerticalTextPosition(JLabel.CENTER);
		enterKey.setBounds(0,0,400,50);
		
		JPanel enterPanel = new JPanel();
		enterPanel.setBounds(0,25,400,50);
		enterPanel.setBackground(new Color(46,124,173));
		enterPanel.add(enterKey);
		add(enterPanel);
		
		JPanel p = new JPanel();
		p.setBounds(0,0,400,50);
		p.setBackground(new Color(46,124,173));
		p.add(m);
		add(p);
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_ENTER) {
			setVisible(false); 
			dispose();
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
