package gameview;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class InfoWindow extends JFrame implements ActionListener{
	
	JPanel controls;
	Boolean cb = true;
	JPanel rules;
	Boolean rb = false;
	JButton changeButton;
	JButton b = new JButton();
	JLabel label = new JLabel();
	
	public InfoWindow() {
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
		setSize(600, 600);
		setResizable(false);
		setTitle("Info");
		
		controls = new JPanel();
		rules = new JPanel();
		
		label.setBounds(0,0,600,500);
		
		changeButton = new JButton();
		changeButton.addActionListener(this);
		changeButton.setBounds(200, 500, 200, 50);
		
		showPanel();
		validate();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == changeButton) {
			if(cb == true) {
				cb = false;
				rb = true;
				showPanel();
				validate();
			}
			else {
				cb = true;
				rb = false;
				showPanel();
				validate();
			}
		}
	}
	
	public void showPanel() {
		if(rb == true) {
			controls.setVisible(cb);
			
			rules.setLayout(null);
			rules.setBackground(new Color(46,124,173));
			
			label.setIcon(new ImageIcon("RulesScreen.jpg"));
			changeButton.setIcon(new ImageIcon("ControlsButton.jpg"));
			
			rules.add(changeButton);
			rules.add(label);
			rules.setVisible(rb);
			validate();
			add(rules);
		}
		else {
			rules.setVisible(rb);
			
			controls.setLayout(null);
			controls.setBackground(new Color(46,124,173));
			controls.add(label);
			
			label.setIcon(new ImageIcon("controlsScreen.jpg"));
			changeButton.setIcon(new ImageIcon("RulesButton.jpg"));
			
			controls.add(changeButton);
			controls.setVisible(cb);
			validate();
			add(controls);
			
		}
	}
}
