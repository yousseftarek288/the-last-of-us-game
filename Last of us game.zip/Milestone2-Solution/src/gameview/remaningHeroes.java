package gameview;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JLabel;

import engine.Game;
import model.characters.Explorer;
import model.characters.Fighter;
import model.characters.Hero;
import model.characters.Medic;

public class remaningHeroes extends JFrame implements KeyListener{
	
	JLabel remaningHeroesLabel;
	
	public remaningHeroes() {
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
		setSize(200, 800);
		setResizable(false);
		setTitle("Remaning Heroes");
		remaningHeroesLabel = new JLabel();
		remaningHeroesLabel.setLayout(new FlowLayout());
		
		remaningHeroesLabel.setBackground(new Color(46, 124, 173));
		remaningHeroesLabel.setOpaque(true);
	}
	
	public void update() {
		remaningHeroesLabel.removeAll();
		JLabel rh = new JLabel();
		rh.setText("Remaning Heroes");
		remaningHeroesLabel.add(rh);
		for(int i = 0; i < Game.heroes.size(); i += 1) {
			Hero currHero = Game.heroes.get(i);
			if(currHero == GUI.selectedHero) {
				continue;
			}
			JLabel heroName = new JLabel();
			heroName.setText("Hero " + i + " : " + currHero.getName());
			
			JLabel curHP = new JLabel();
			curHP.setText("HP: " + currHero.getCurrentHp());
			
			JLabel heroType = new JLabel();
			if(currHero instanceof Medic) {
				heroType.setText("Type: Medic");			
			}
			else if(currHero instanceof Fighter) {
				heroType.setText("Type: Fighter");			
			}
			else if(currHero instanceof Explorer) {
				heroType.setText("Type: Explorer");			
			}
			
			JLabel actionPoints = new JLabel();
			actionPoints.setText("Action Points: " + currHero.getActionsAvailable());
			
			JLabel AttackDmg = new JLabel();
			AttackDmg.setText("Attack Damage: " + currHero.getAttackDmg());
			
			JLabel supplyInt = new JLabel();
			supplyInt.setText("supplies : " + currHero.getSupplyInventory().size());
			
			JLabel vaccineInt = new JLabel();
			vaccineInt.setText("vaccines : " + currHero.getVaccineInventory().size());
			
			JLabel specialAbility = new JLabel();
			specialAbility.setText("Used Special Ability : " + currHero.isSpecialAction());
			
			JLabel targetName = new JLabel();
			if(currHero.getTarget() == null) {
				targetName.setText("Current Target: null");
			}
			else {
				targetName.setText("Current Target: " + currHero.getTarget().getName());
			}
			
			JLabel targetHP = new JLabel();
			if(currHero.getTarget() == null) {
				targetHP.setText("Current Target HP: null");
			}
			else {
				targetHP.setText("Current Target HP: " + currHero.getTarget().getCurrentHp());
			}
			
			JLabel space = new JLabel();
			space.setText("kjadnfkakdlfjmadlkskj");
			space.setForeground(new Color(46, 124, 173));
			
			
			remaningHeroesLabel.add(heroName);
			remaningHeroesLabel.add(curHP);
			remaningHeroesLabel.add(AttackDmg);
			remaningHeroesLabel.add(supplyInt);
			remaningHeroesLabel.add(vaccineInt);
			remaningHeroesLabel.add(specialAbility);
			remaningHeroesLabel.add(targetHP);
			remaningHeroesLabel.add(targetName);
			remaningHeroesLabel.add(space);
		}
		
		remaningHeroesLabel.revalidate();
		remaningHeroesLabel.repaint();
		add(remaningHeroesLabel);
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
