package gameview;

import javax.swing.*;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;

import engine.Game;
import exceptions.InvalidTargetException;
import exceptions.MovementException;
import exceptions.NoAvailableResourcesException;
import exceptions.NotEnoughActionsException;
import model.characters.Direction;
import model.characters.Explorer;
import model.characters.Fighter;
import model.characters.Hero;
import model.characters.Medic;
import model.characters.Zombie;
import model.collectibles.Supply;
import model.collectibles.Vaccine;
import model.world.CharacterCell;
import model.world.CollectibleCell;
import model.world.TrapCell;

public class GUI extends JFrame implements ActionListener, KeyListener {
	JLabel backGround = new JLabel();
	JButton start;
	JButton[] heroButtons;
	JPanel menu;
	static Hero selectedHero;
	JButton[][] mapButtons;
	JPanel gamePanel = new JPanel();
	JLabel updateLabel = new JLabel();
	JButton info;
	JPanel infoPanel;
	JPanel endGame = new JPanel();
	String lastKeyPressed;
	remaningHeroes rh;
	JButton remButton = new JButton();
	Direction dir;
	
	public GUI() {
		try {
			Game.loadHeroes("Heroes.csv");
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this, "Hero File is not Available", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setSize(800, 800);
		setResizable(false);
		setTitle("Team 285 Game");
		addKeyListener(this);
		
		menu = new JPanel();
		menu.setLayout(null);
		backGround.setIcon(new ImageIcon("backGround.jpg"));
		backGround.setBounds(0, 0, 800, 800);
		menu.setBackground(new Color(150,151,150));
		menu.add(backGround);
		validate();
		heroButtons = new JButton[Game.availableHeroes.size()];
		addHeroButtonsToMenu();
		
		add(menu);
		validate();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == remButton) {
			rh = new remaningHeroes();
		}
		if(e.getSource() == start) {
			if(selectedHero == null) {
				new Error("You Need To Choose A Hero");
			}
			else {
				try {
					NewGame();
				} catch (MovementException e1) {
					new Error(e1.getMessage());
				} catch (NotEnoughActionsException e1) {
					new Error(e1.getMessage());
				}
			}
		}
		if(e.getSource() == info) {
			new InfoWindow();
		}
		for(int i = 0; i < Game.availableHeroes.size(); i += 1) {
			if(e.getSource() == heroButtons[i] ) {
				selectedHero = Game.availableHeroes.get(i);
				selectedHero.setNumber(i);
				break;
			}
		}
		if(mapButtons != null) {
			for(int i = 0; i < mapButtons.length; i += 1) {
				for(int j = 0; j < mapButtons.length; j += 1) {
					if(e.getSource() == mapButtons[i][j]) {
						if(Game.map[14-i][j] instanceof CharacterCell) {
							if( ((CharacterCell) Game.map[14-i][j]).getCharacter() instanceof Hero) {
								selectedHero = (Hero) ((CharacterCell) Game.map[14-i][j]).getCharacter();
								try {
									updateMap();
								} catch (MovementException e1) {
									new Error(e1.getMessage());
								} catch (NotEnoughActionsException e1) {
									new Error(e1.getMessage());
								}
						}
					}
				}
			}
		}
		}
		
	}
	public void addHeroButtonsToMenu() {
		for (int i = 0; i < heroButtons.length; i++) {
			heroButtons[i] = new JButton();
			heroButtons[i].setBounds(10 + 195 * (i % 4), 30 + 310 * (i / 4), 180, 300);
			heroButtons[i].setIcon(new ImageIcon("Hero" + i + ".jpg"));
			heroButtons[i].addActionListener(this);
			heroButtons[i].setFocusable(false);
			backGround.add(heroButtons[i]);
		}
		
		start = new JButton();
		start.addActionListener(this);
		start.setBounds(250, 675, 200, 50);
		start.setIcon(new ImageIcon("Start.jpg"));
		start.setFocusable(false);
		backGround.add(start);
		
		info = new JButton();
		info.addActionListener(this);
		info.setBounds(460, 675, 50, 50);
		info.setIcon(new ImageIcon("infoButton.jpg"));
		info.setFocusable(false);
		backGround.add(info);
	}
	
	
	private void NewGame() throws MovementException, NotEnoughActionsException {
		menu.setVisible(false);
		Game.startGame(selectedHero);
		rh = new remaningHeroes();
		updateMap();
		validate();
	}
	
	public void updateMap() throws MovementException, NotEnoughActionsException {
		rh.update();
		updateLabel.setBounds(0, 0, 800, 800);
		gamePanel.removeAll();
		updateLabel.removeAll();
		infoPanel = new JPanel();
		mapButtons = new JButton[15][15];
		
		gamePanel.setLayout(new GridLayout(15, 15));
		infoPanel.setLayout(null);
		infoPanel.setBounds(0,0,600,50);
		gamePanel.setBounds(0,50, 790, 715);
		
		for (int i = 0; i < 15; i++) {
			for (int j = 0; j < 15; j++) {
				mapButtons[i][j] = new JButton();
				
				if(Game.map[14-i][j].isVisible()) {
					if (Game.map[14-i][j] instanceof CharacterCell) {
	                    CharacterCell c = (CharacterCell) Game.map[14-i][j];
	                    if (c.getCharacter() instanceof Hero) {
	                    	mapButtons[i][j].setIcon(new ImageIcon(c.getCharacter().getName() + ".jpg"));
	                    } 
	                    else if (c.getCharacter() instanceof Zombie) {
	                        mapButtons[i][j].setIcon(new ImageIcon("Zombie.jpg"));
	        				
	                    }
	                    else if(c.getCharacter() == null){
	                    	mapButtons[i][j].setIcon(new ImageIcon("pixelMap.jpg"));
	                    }
	                }
					else if(Game.map[14-i][j] instanceof CollectibleCell) {
						if( ((CollectibleCell) Game.map[14-i][j]).getCollectible() instanceof Vaccine) {
							mapButtons[i][j].setIcon(new ImageIcon("vacPixel.jpg"));
						}
						else if(((CollectibleCell) Game.map[14-i][j]).getCollectible() instanceof Supply){
							mapButtons[i][j].setIcon(new ImageIcon("supPixel.jpg"));
						}
					}
					else if(Game.map[14-i][j] instanceof TrapCell){
						mapButtons[i][j].setIcon(new ImageIcon("pixelMap.jpg"));
					}
					else {
						mapButtons[i][j].setIcon(new ImageIcon("pixelMap.jpg"));	
						
					}
				}
				else {
					mapButtons[i][j].setIcon(new ImageIcon("notVis.jpg"));
				}
				
				validate();
				mapButtons[i][j].addActionListener(this);
				mapButtons[i][j].setFocusable(false);
				gamePanel.add(mapButtons[i][j]);
			}
		}
		
		JLabel heroName = new JLabel();
		heroName.setBounds(0,0,450,10);
		heroName.setText("Current Hero: " + selectedHero.getName());
		updateLabel.add(heroName);
		
		JLabel curHP = new JLabel();
		curHP.setBounds(0,0,600,60);
		curHP.setText("HP: " + selectedHero.getCurrentHp());
		updateLabel.add(curHP);
		
		JLabel heroType = new JLabel();
		heroType.setBounds(0,0,600,35);
		if(selectedHero instanceof Medic) {
			heroType.setText("Type: Medic");			
		}
		else if(selectedHero instanceof Fighter) {
			heroType.setText("Type: Fighter");			
		}
		else if(selectedHero instanceof Explorer) {
			heroType.setText("Type: Explorer");			
		}
		updateLabel.add(heroType);
		
		JLabel actionPoints = new JLabel();
		actionPoints.setBounds(0,0,600,80);
		actionPoints.setText("Action Points: " + selectedHero.getActionsAvailable());
		updateLabel.add(actionPoints);
		
		JLabel AttackDmg = new JLabel();
		AttackDmg.setBounds(200,0,600,60);
		AttackDmg.setText("Attack Damage: " + selectedHero.getAttackDmg());
		updateLabel.add(AttackDmg);
		
		JLabel supplyInt = new JLabel();
		supplyInt.setBounds(200,-5,600,20);
		supplyInt.setText("supplies : " + selectedHero.getSupplyInventory().size());
		updateLabel.add(supplyInt);
		
		JLabel vaccineInt = new JLabel();
		vaccineInt.setBounds(200,0,600,35);
		vaccineInt.setText("vaccines : " + selectedHero.getVaccineInventory().size());
		updateLabel.add(vaccineInt);
		
		JLabel specialAbility = new JLabel();
		specialAbility.setBounds(200,0,600,90);
		specialAbility.setText("Used Special Ability : " + selectedHero.isSpecialAction());
		updateLabel.add(specialAbility);
		
		JLabel targetName = new JLabel();
		targetName.setBounds(400,0,600,10);
		if(selectedHero.getTarget() == null) {
			targetName.setText("Current Target: null");
		}
		else {
			targetName.setText("Current Target: " + selectedHero.getTarget().getName());
		}
		updateLabel.add(targetName);
		
		JLabel targetHP = new JLabel();
		targetHP.setBounds(400,0,600,30);
		if(selectedHero.getTarget() == null) {
			targetHP.setText("Current Target HP: null");
		}
		else {
			targetHP.setText("Current Target HP: " + selectedHero.getTarget().getCurrentHp());
		}
		updateLabel.add(targetHP);
		
		info.setBounds(720,3,50,50);
		updateLabel.add(info);
		
		remButton.setBounds(550, 3, 165, 50);
		remButton.setIcon(new ImageIcon("remButton.jpg"));
		//updateLabel.add(remButton);
		
		gamePanel.revalidate();
		gamePanel.repaint();
		updateLabel.revalidate();
		updateLabel.repaint();
		updateLabel.add(gamePanel);
		add(updateLabel);
		
		
		if(Game.checkWin()) {
			endGame.setVisible(true);
			gamePanel.setVisible(false);
			updateLabel.setVisible(false);
			JLabel message = new JLabel();
			message.setIcon(new ImageIcon("winScreen.jpg"));
			endGame.add(message);
			add(endGame);
		}
		if(Game.checkGameOver()) {
			endGame.setVisible(true);
			gamePanel.setVisible(false);
			updateLabel.setVisible(false);
			JLabel message = new JLabel();
			message.setIcon(new ImageIcon("loseScreen.jpg"));
			endGame.add(message);
			add(endGame);
		}
	}
	
	public static void main(String args[]) {
		new GUI();
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_W || e.getKeyCode() == KeyEvent.VK_UP) {
			dir = Direction.UP;
			try {
				if(selectedHero.getLocation().x > 0 && selectedHero.getLocation().x < 14 && selectedHero.getLocation().y > 0 && selectedHero.getLocation().y < 14) {
					if(Game.map[selectedHero.getLocation().x + 1][selectedHero.getLocation().y] instanceof TrapCell) {
						new Error("You Entered A Trap Cell");
					}
				}
				selectedHero.move(dir);
				updateMap();
			} catch (MovementException e1) {
				new Error(e1.getMessage());
			} catch (NotEnoughActionsException e1) {
				new Error(e1.getMessage());
			}
		}
		else if(e.getKeyCode() == KeyEvent.VK_S || e.getKeyCode() == KeyEvent.VK_DOWN) {
			dir = Direction.DOWN;
			try {
				if(selectedHero.getLocation().x > 0 && selectedHero.getLocation().x < 14 && selectedHero.getLocation().y > 0 && selectedHero.getLocation().y < 14) {
					if(Game.map[selectedHero.getLocation().x - 1][selectedHero.getLocation().y] instanceof TrapCell) {
						new Error("You Entered A Trap Cell");
					}
				}
				selectedHero.move(dir);
				updateMap();
			} catch (MovementException e1) {
				new Error(e1.getMessage());
			} catch (NotEnoughActionsException e1) {
				new Error(e1.getMessage());
			}
		}
		else if(e.getKeyCode() == KeyEvent.VK_A || e.getKeyCode() == KeyEvent.VK_LEFT) {
			dir = Direction.LEFT;
			try {
				if(selectedHero.getLocation().x > 0 && selectedHero.getLocation().x < 14 && selectedHero.getLocation().y > 0 && selectedHero.getLocation().y < 14) {
					if(Game.map[selectedHero.getLocation().x][selectedHero.getLocation().y - 1] instanceof TrapCell) {
						new Error("You Entered A Trap Cell");
					}
				}
				selectedHero.move(dir);
				updateMap();
			} catch (MovementException e1) {
				new Error(e1.getMessage());
			} catch (NotEnoughActionsException e1) {
				new Error(e1.getMessage());
			}
		}
		else if(e.getKeyCode() == KeyEvent.VK_D || e.getKeyCode() == KeyEvent.VK_RIGHT) {
			dir = Direction.RIGHT;
			try {
				if(selectedHero.getLocation().x > 0 && selectedHero.getLocation().x < 14 && selectedHero.getLocation().y > 0 && selectedHero.getLocation().y < 14) {
					if(Game.map[selectedHero.getLocation().x][selectedHero.getLocation().y + 1] instanceof TrapCell) {
						new Error("You Entered A Trap Cell");
					}
				}
				selectedHero.move(dir);
				updateMap();
			} catch (MovementException e1) {
				new Error(e1.getMessage());
			} catch (NotEnoughActionsException e1) {
				new Error(e1.getMessage());
			}
		}
		else if(e.getKeyCode() == KeyEvent.VK_Q) {
			if(selectedHero.getTarget() != null) {
				try {
					selectedHero.attack();
					try {
						updateMap();
					} catch (MovementException e1) {
						new Error(e1.getMessage());
					}
				} catch (NotEnoughActionsException e1) {
					new Error(e1.getMessage());
				} catch (InvalidTargetException e1) {
					new Error(e1.getMessage());
				}
				if(selectedHero.getTarget().getCurrentHp() <= 0) {
					selectedHero.setTarget(null);
				}
			}	
			else {
				new Error("no Target");
			}
		}
		else if(e.getKeyCode() == KeyEvent.VK_F) {
			try {
				if(selectedHero instanceof Medic && selectedHero.getTarget() == null) {
					new Error("No Target To Heal");
				}
				else {
					selectedHero.useSpecial();
				}
				try {
					updateMap();
				}  catch (MovementException e1) {
					new Error(e1.getMessage());
				} catch (NotEnoughActionsException e1) {
					new Error(e1.getMessage());
				}
			} catch (NoAvailableResourcesException e1) {
				new Error(e1.getMessage());
			} catch (InvalidTargetException e1) {
				new Error(e1.getMessage());
			}
		}
		else if(e.getKeyCode() == KeyEvent.VK_C) {
			try {
				selectedHero.cure();
				try {
					updateMap();
				} catch (MovementException e1) {
					new Error(e1.getMessage());
				}
			} catch (NoAvailableResourcesException e1) {
				new Error(e1.getMessage());
			} catch (InvalidTargetException e1) {
				new Error(e1.getMessage());
			} catch (NotEnoughActionsException e1) {
				new Error(e1.getMessage());
			}
		}
		else if(e.getKeyCode() == KeyEvent.VK_E) {
			try {
				Game.endTurn();
				try {
					updateMap();
				} catch (MovementException e1) {
					new Error(e1.getMessage());
				}
			} catch (NotEnoughActionsException e1) {
				new Error(e1.getMessage());
			} catch (InvalidTargetException e1) {
				new Error(e1.getMessage());
			}
		}
		else if(e.getKeyCode() == KeyEvent.VK_M) {
				int x = selectedHero.getLocation().x;
				int y = selectedHero.getLocation().y;
				for(int i = x - 1; i < x + 2; i += 1) {
					for(int j = y - 1; j < y + 2; j += 1) {
						if(i <= 14 && i >= 0 && j <= 14 && j >= 0) {
							if(Game.map[i][j] instanceof CharacterCell) {
								if(((CharacterCell) Game.map[i][j]).getCharacter() instanceof Zombie) {
									selectedHero.setTarget(((CharacterCell) Game.map[i][j]).getCharacter());
									try {
										updateMap();
									} catch (MovementException e1) {
										new Error(e1.getMessage());
									} catch (NotEnoughActionsException e1) {
										new Error(e1.getMessage());
									}
								}
							}
							
					}
				}
				}
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
	}
}
