package viewgame;

public class GUI {

	public GUI() {
		// TODO Auto-generated constructor stub
	}

}
